import React from 'react'
import Carousel from 'react-bootstrap/Carousel'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'
import Header from '../includes/header'
//import Navbar from 'react-bootstrap/Navbar'
import TopViewedProductsPage from './TopViewedProductsPage'

const AboutPage = () => {
    return(
        <div>
            <Header />
            <Carousel className="carousel slide container">
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.unsplash.com/photo-1583947215259-38e31be8751f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
                    alt="First slide"
                    width='500px' height='500px'
                  />
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                    alt="Third slide"
                    width='500px' height='500px'
                  />
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.unsplash.com/photo-1513116476489-7635e79feb27?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1993&q=80"
                    alt="Third slide"
                    width='500px' height='500px'
                  />
                </Carousel.Item>
            </Carousel>
            <Container className="mt-4">
                <Row>
                    <Col>
                        <Card border="light" id="about">
                            <h1>About</h1>
                            <p> 
                            A product description is the marketing copy that explains what a product is and why it’s worth purchasing. The purpose of a product description is to supply customers with important information about the features and benefits of the product so they’re compelled to buy.
                            However, entrepreneurs and marketers, even professional copywriters, alike are susceptible to a common mistake that comes up when writing product descriptions: writing product descriptions that simply describe your products, as a supplement to
                            The best product descriptions address your target audience directly and personally. You ask and answer questions as if you’re having a conversation with them. You choose the words your ideal buyer uses. You use the word you.
                            </p>
                        </Card>
                    </Col>
                    <Col md="auto">
                        <Card style={{ width: '18rem' }} border="info">
                            <Card.Body>
                              <Card.Title>Welcome!</Card.Title>
                              <Card.Text>
                               Already a User?
                              </Card.Text>
                              <Button variant="primary" className='btn-dark' href="/signIn">Sign in</Button>
                              <Card.Text>
                               New User?
                              </Card.Text>
                              <Button variant="primary" className='btn-dark' href="/register">Sign Up</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
            <TopViewedProductsPage />
        </div>
    )
}

export default AboutPage